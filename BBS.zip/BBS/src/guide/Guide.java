package guide;

public class Guide {
	
	private String guideID;
	private String guidePassword;
	private String guideName;
	private String guideGender;
	private String guideAge;
	private String guidePnumber;
	private String guideCar;
	private String guideLive;
	
	public String getGuideID() {
		return guideID;
	}
	public void setGuideID(String guideID) {
		this.guideID = guideID;
	}
	public String getGuidePassword() {
		return guidePassword;
	}
	public void setGuidePassword(String guidePassword) {
		this.guidePassword = guidePassword;
	}
	public String getGuideName() {
		return guideName;
	}
	public void setGuideName(String guideName) {
		this.guideName = guideName;
	}
	public String getGuideGender() {
		return guideGender;
	}
	public void setGuideGender(String guideGender) {
		this.guideGender = guideGender;
	}
	public String getGuideAge() {
		return guideAge;
	}
	public void setGuideAge(String guideAge) {
		this.guideAge = guideAge;
	}
	public String getGuidePnumber() {
		return guidePnumber;
	}
	public void setGuidePnumber(String guidePnumber) {
		this.guidePnumber = guidePnumber;
	}
	public String getGuideCar() {
		return guideCar;
	}
	public void setGuideCar(String guideCar) {
		this.guideCar = guideCar;
	}
	public String getGuideLive() {
		return guideLive;
	}
	public void setGuideLive(String guideLive) {
		this.guideLive = guideLive;
	}

}
