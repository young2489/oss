package guide;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GuideDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public GuideDAO() {
		try {
			String dbURL ="jdbc:mysql://localhost:3306/BBS";
			String dbID = "root";
			String dbPassword = "dhvmsthtm";
			Class.forName("com.mysql.jdbc.Drvier");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int login(String guideID, String guidePassword) {
		String SQL = "SELECT guidePassword FROM GUIDE WHERE guideID = ?";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, guideID);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if(rs.getString(1).equals(guidePassword))
					return 1; // �α��� ����
				else
					return 0; // ��й�ȣ ����ġ
			}
			return -1; // ���̵� ����
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -2; //�����ͺ��̽� ����
	}
	
	public int join(Guide guide) {
		String SQL = "Insert INTO GUIDE VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, guide.getGuideID());
			pstmt.setString(2, guide.getGuidePassword());
			pstmt.setString(3, guide.getGuideName());
			pstmt.setString(4, guide.getGuideGender());
			pstmt.setString(5, guide.getGuideAge());
			pstmt.setString(6, guide.getGuidePnumber());
			pstmt.setString(7, guide.getGuideCar());
			pstmt.setString(8, guide.getGuideLive());
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}


}
